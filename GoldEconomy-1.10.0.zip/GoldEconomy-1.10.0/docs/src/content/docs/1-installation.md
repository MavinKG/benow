---
title: Installation
slug: installation
---

To install TheGoldEconomy you need to follow these steps:
1. Download the latest release from [Modrinth](https://modrinth.com/plugin/thegoldeconomy)
2. Download the Vault dependency from [Spigot](https://www.spigotmc.org/resources/vault.34315/)
3. Put both files in your `plugins` folder
4. Restart your server to generate the config file
5. Edit the config file to your liking
6. Have fun!