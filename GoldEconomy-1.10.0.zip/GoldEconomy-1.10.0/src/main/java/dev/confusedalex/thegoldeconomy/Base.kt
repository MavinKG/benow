package dev.confusedalex.thegoldeconomy

enum class Base {
    NUGGETS, INGOTS, RAW
}